/* PtrFunc.C */
/* Mostra o uso de ponteiro para fun��o */
#include <stdio.h> 
#include <stdlib.h>

void doisbeep(void); /* prot�tipo */

int main()
{
	void (*pf)(void);/* ponteiro p/f��o void que recebe void */

	pf = doisbeep; /* nome da fun��o sem os par�nteses */

	(*pf)();/* chama a fun��o */

	system("PAUSE");	
	return 0;			
}

/* doisbeep() */
/* toca o alto-falante duas vezes */
void doisbeep(void)
{
	unsigned i;
	printf("\a");
	for(i=0; i < 800000 ; i++); /* dar um tempo */
	printf("\a");
}

